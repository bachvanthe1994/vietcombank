package creaditCardPaymentUI;

public class creaditCardPaymentUI {

	public static final String DYNAMIC_LINEAERLAYOUT_BY_TEXT = "//android.widget.LinearLayout[@resource-id='com.VCB:id/LinContent' and @index='%s']";
	public static final String DYNAMIC_TEXT_VIEW= "//android.widget.TextView[@resource-id='%s']";

	//DYNAMIC TEXT
	
	public static final String SO_TK_THE= "Số tài khoản thẻ";
	public static final String TINH_TRANG_THE= "Tình trạng thẻ";
	public static final String TONG_SO_TT_SAO_KE= "Tổng số đã thanh toán trong kỳ sao kê";
	public static final String SO_TIEN_TOI_THIEU_TT= "Số tiền tối thiểu còn phải thanh toán";
	public static final String SO_TIEN_SK_TT= "Số tiền sao kê còn phải thanh toán";
	public static final String SO_TIEN_DU_NO_TT= "Số tiền dư nợ còn phải thanh toán";
	public static final String SO_TIEN_TT= "Số tiền thanh toán";
	public static final String TT_GIAO_DICH= "Thông tin giao dịch";
	public static final String XAC_NHAN_TT= "Xác nhận thông tin";
	public static final String TK_NGUON= "Tài khoản nguồn";
	public static final String XAC_THUC_GD= "Xác thực giao dịch";
	public static final String GD_THANH_CONG= "GIAO DỊCH THÀNH CÔNG";
	public static final String SO_THE= "Số thẻ";
	public static final String MA_GIAO_DICH= "Mã giao dịch";
	public static final String BAO_CAO_GD= "Báo cáo giao dịch";
	public static final String TT_THE_TD= "Thanh toán thẻ tín dụng";
	public static final String CHI_TIET_GD= "Chi tiết giao dịch";
	public static final String SO_LENH_GD= "Số lệnh giao dịch";
	public static final String TK_THE_TRICH_NO= "Tài khoản/thẻ trích nợ";
	public static final String SO_TIEN_GD= "Số tiền giao dịch";

	
}
