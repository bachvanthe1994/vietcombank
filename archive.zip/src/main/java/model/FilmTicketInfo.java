package model;

public class FilmTicketInfo {
	public String filmName;
	public String time;
	public String filmDuration;
	public String cinemaName;
	public String cinemaAddress;
	public String price;
	public String numberOfSeats;
	
}