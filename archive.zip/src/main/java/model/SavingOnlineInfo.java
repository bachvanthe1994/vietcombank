package model;

public class SavingOnlineInfo {
	public String sourceAccount;
	public String term;
	public String money;
	public String formOfPayment;

	public SavingOnlineInfo(String sourceAccount, String term, String money, String formOfPayment) {
		this.sourceAccount = sourceAccount;
		this.term = term;
		this.money = money;
		this.formOfPayment = formOfPayment;

	}
}
