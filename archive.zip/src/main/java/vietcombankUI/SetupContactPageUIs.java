package vietcombankUI;

public class SetupContactPageUIs {
	public static final String LIST_CONTACT = "//android.widget.LinearLayout[@resource-id='com.VCB:id/llListContact']//android.widget.ImageView[@resource-id='com.VCB:id/ivCheck']"; 


}
