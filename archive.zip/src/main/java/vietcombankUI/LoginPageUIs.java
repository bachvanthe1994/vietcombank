package vietcombankUI;

public class LoginPageUIs {
	public static final String PHONE_NUMBER_TEXT_FIELD = "//android.widget.EditText[@resource-id='com.VCB:id/edtInput']";
	public static final String ICON_CHANGE_LANGUAGE = "//android.widget.ImageView[@resoucre-id='com.VCB:id/ImgFlag']";
	public static final String TEXT_LANGUAGE = "//android.widget.TextView[@resoucre-id='com.VCB:id/tvLanguage']";
}
