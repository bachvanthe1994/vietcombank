package vietcombankUI;

public class TransferMoneyCharityPageUIs {
    public static final String TEXT_VIEW_CURRENCY_CHARITY = "//android.widget.EditText['Số tiền ủng hộ']/following-sibling::android.widget.TextView";
    public static final String TEXT_VIEW_LIST_ORGANIZATION = "//android.widget.ListView//android.widget.TextView";
}
