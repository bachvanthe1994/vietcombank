package vietcombankUI.saving_online;

public class SavingOnlineUIs {
	public static final String AVAILABLE_BALANCE_SAVING_ONLINE = "//android.widget.TextView[@text = 'Thông tin giao dịch']/parent::android.widget.LinearLayout//following-sibling::android.widget.LinearLayout[@resource-id = 'com.VCB:id/llInfoBottom']//android.widget.TextView[@text = '%s']/following-sibling::android.widget.TextView";
	public static final String DYNAMIC_DROPDOWN_BY_LABEL = "//android.widget.TextView[@text = '%s']/following-sibling::android.widget.LinearLayout//android.widget.ImageView";
	
}
