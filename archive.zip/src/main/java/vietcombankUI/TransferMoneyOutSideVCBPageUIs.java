package vietcombankUI;

public class TransferMoneyOutSideVCBPageUIs {
	public static final String SOURCE_ACCOUNT = "//android.widget.TextView[@text = 'Tài khoản nguồn']/following-sibling::android.widget.LinearLayout/android.widget.TextView";
	public static final String PASSWORD_CONFIRM_INPUT = "//android.widget.EditText[@text = 'Nhập mật khẩu']";
}
