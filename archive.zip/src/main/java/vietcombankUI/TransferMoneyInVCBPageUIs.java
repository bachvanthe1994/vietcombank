package vietcombankUI;

public class TransferMoneyInVCBPageUIs {
	public static final String DYNAMIC_CONFIRM_SECOND_LINE_INFO = "//android.widget.TextView[@text='%s']//parent::android.widget.LinearLayout/following-sibling::android.widget.TextView";
	public static final String FREQUENCY_NUMBER_INPUT = "//android.widget.TextView[@text = 'Tần suất']//parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/android.widget.EditText";
}
