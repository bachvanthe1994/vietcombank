package vietcombank_test_data;

public class Register_Data {
	public static class RegisterData {
	public static final String TEN_DANG_NHAP = "0335059863";
	public static final String MAT_KHAU = "1e9978d3";
	public static final String MA_KIEM_TRA = "0981790798";
	
    }

    public class Messagess {
	public static final String WELCOME_REGISTER = "Quý khách chưa đăng ký dịch vụ VCB-Mobile B@nking.Quý khách "
			+ "có thể đăng ký dịch vụ tại quầy giao dịch hoặc đăng ký ngay tại đây thông qua:\r\n" + 
			"\r\n" + 
			"";
	public static final String MESSAGE_REGISTER_FAIL = "Mã kiểm tra không chính xác. Quý khách vui lòng kiểm tra lại.";

    }

    public class UI {
	public static final String REGISTER_NOW_BUTTON = "Đăng ký VCB-Mobile B@nking";
	public static final String VCB_IB_BUTTON = "VCB-iB@nking";
	public static final String VCB_BANKPLUS_BUTTON = "VCB-Mobile Bankplus";


    }

}
