package vietcombank_test_data;

public class TransferMoneyStatus_Data {

	public static class Output {
		public static final String NOTE = "Lưu ý: Tra cứu trạng thái lệnh giao dịch chuyển tiền định kỳ hoặc ngày tương lai";
		public static final String WAITING_STATUS = "Chờ xử lý";
		public static final String CANCEL_STATUS = "Đã hủy";
	}

}
