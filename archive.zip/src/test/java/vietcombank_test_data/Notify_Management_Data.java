package vietcombank_test_data;

public class Notify_Management_Data {

	public class ACCOUNT {
		public static final String ACCOUNT_01 = "0091000594839";
		public static final String ACCOUNT_02 = "0019965487";
		public static final String ACCOUNT_03 = "0019966611";
		public static final String ACCOUNT_04 = "0541001555240";
	}

}
