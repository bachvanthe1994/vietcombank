package vietcombank_test_data;

public class Transfer_Limit {

    public static class Valid_Account {
	
    }

    public class Invalid_Account {
	

    }
}
