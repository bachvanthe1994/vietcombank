package vietcombank_test_data;

public class Shopping_Online {

    public class Valid_Account {
    	public static final String LOCATOR_SEARCH = "CGV";


    }
}
