package vietcombank_test_data;

public class Creadit_Card_Payment_Data {

	public class Tittle {
		public static final String TEXT_STK = "Số tài khoản";
		public static final String TEXT_SDKD = "Số dư khả dụng";
		public static final String SELECT_CARD= "Chọn số thẻ";
		public static final String OTP_NUMBER= "123456";


	}
}
