package vietcombank_test_data;

public class SettingVCBSmartOTP_Data {
	public static final String TITTLE_SETTING = "Cài đặt và sử dụng mật khẩu VCB-Smart OTP để nâng cao tính bảo mật và an toàn cho giao dịch trên ứng dụng VCB-Mobile B@nking";
	public static final String SMART_OTP = "123123";
	public static final String VALUE_OTP = "666888";

	public static final String MESSEGE_CANCEL_SMART_OTP = "Quý khách đã hủy xác thực bằng VCB-Smart OTP thành công. Vui lòng đăng nhập lại ứng dụng.";
	public static final String MESSEGE_SUCCESS_SMART_OTP = "Đăng ký phương thức xác thực VCB-Smart OTP thành công. Vì lí do bảo mật, ứng dụng chỉ cho phép sử dụng phương thức xác thực VCB-Smart OTP khi quý khách đã thực hiện thành công 05 giao dịch tài chính bằng SMS OTP từ khi kích hoạt dịch vụ";
	public static final String MESSEGE_CONFIRM_CANCEL= "Quý khách có chắc chắn muốn hủy phương thức xác thực bằng VCB-Smart OTP không?";
}
