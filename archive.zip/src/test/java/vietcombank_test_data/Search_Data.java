package vietcombank_test_data;

public class Search_Data {

  public class VALIDATE {
	  public static final String EXCHANGE_RATE_TITLE = "Tra cứu tỷ giá ngoại tệ";
  }
  
  public class DATA {
	  public static final String USD_MONEY = "19.68";
	  public static final String VND_MONEY = "10000000";
  }
}
