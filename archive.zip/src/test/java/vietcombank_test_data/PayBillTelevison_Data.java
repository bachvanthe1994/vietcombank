package vietcombank_test_data;

import java.util.Arrays;
import java.util.List;

public class PayBillTelevison_Data {
    public static class inputData {
	public static final List<String> CODE_CUSTOMER = Arrays.asList("VTVCABMHB1", "VTVCABMHB2", "VTVCAB000001", "VTVCAB000002", "VTVCAB000003", "1616244", "1616245", "1616246", "1616247",
		"1616248bidv", "1616249bidv", "1616249bidv", "1616250bidv", "1616251bidv", "1616252bidv", "1616253bidv", "1616254bidv", "1616255bidv", "1616256bidv", "1616257bidv");
    }
}
