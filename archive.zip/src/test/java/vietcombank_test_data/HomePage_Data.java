package vietcombank_test_data;

public class HomePage_Data {
	public class Home_Text_Elements{
		public static final String CREDIT_CARD_PAYMENT = "Thanh toán thẻ tín dụng";

	}
}
