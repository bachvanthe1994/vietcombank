package vietcombank_test_data;

public class SavingOnline_Data {
	public static final String SUCCESS_TRANSACTION = "GIAO DỊCH THÀNH CÔNG";
	
}
	

