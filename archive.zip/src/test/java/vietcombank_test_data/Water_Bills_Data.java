package vietcombank_test_data;

import java.util.Arrays;
import java.util.List;

public class Water_Bills_Data {

	public static class DATA {

		public static final String WATER_DAWACO = "Dawaco Đà Nẵng";
		public static final String WATER_BILL_TEXT = "Hóa đơn tiền nước";
		public static final String WATER_BILL_MESSAGE = "Giao dịch không thành công do hóa đơn không còn nợ cước. Quý khách vui lòng kiểm tra lại.";
		public static final List<String> LIST_CUSTOMER_ID = Arrays.asList("", "", "", "", "", "", "", "", "", "");
	}

}
