package vnpay.vietcombank.signin;

public class SignIn_Data {
	public class Message_popup {
		public static final String MESSAGE_POPUP = "Số điện thoại chưa đăng ký hoặc đã ngừng dịch vụ. Quý khách vui lòng đăng ký dịch vụ tại quầy hoặc đăng ký bằng tài khoản VCB-iB@nking/VCB-Mobile Bankplus. Chi tiết liên hệ Hotline 24/7: 1900545413 để được trợ giúp.";
		public static final String MESSAGE_SIGNIN_IB = "VCB-iB@nking";
		public static final String MESSAGE_USED = "Tiếp tục sử dụng dịch vụ";
		public static final String MESSAGE_OTP = "VCB-Smart OTP là phương thức xác thực giao dịch có tính bảo mật cao, đáp ứng yêu cầu của Ngân hàng Nhà nước đối với các giao dịch trên VCB-Mobile B@nking. Vui lòng nhấn Đăng ký ngay để có những trải nghiệm hoàn toàn khác biệt.";
		public static final String BUTTON_CANCEL = "Hủy";
		public static final String BUTTON_NEXT = "Tiếp tục";
	}
	
	public class Buttons_Other{
		public static final String SIGNIN_MOBILE = "Đăng ký VCB-Mobile B@nking";
		public static final String MASSAGE_SIGNIN_MOBILE = "Quý khách chưa đăng ký dịch vụ VCB-Mobile B@nking.Quý khách có thể đăng ký dịch vụ tại quầy giao dịch hoặc đăng ký ngay tại đây thông qua:\r\n" + 
				"\r\n" + 
				"";
		
	}
}
